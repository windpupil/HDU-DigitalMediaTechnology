﻿namespace smSQLServerTest
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btConnect = new System.Windows.Forms.Button();
            this.btQueryAll = new System.Windows.Forms.Button();
            this.btInsertToDatabase = new System.Windows.Forms.Button();
            this.btModifiFeildValue = new System.Windows.Forms.Button();
            this.btDeleteFeildValue = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btDisConnect = new System.Windows.Forms.Button();
            this.tB_Name = new System.Windows.Forms.TextBox();
            this.tB_Mail = new System.Windows.Forms.TextBox();
            this.tB_Phone = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cB_Sex = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cB_tj = new System.Windows.Forms.ComboBox();
            this.chk_mode = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btConnect
            // 
            this.btConnect.Location = new System.Drawing.Point(48, 260);
            this.btConnect.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btConnect.Name = "btConnect";
            this.btConnect.Size = new System.Drawing.Size(150, 46);
            this.btConnect.TabIndex = 0;
            this.btConnect.Text = "连接";
            this.btConnect.UseVisualStyleBackColor = true;
            this.btConnect.Click += new System.EventHandler(this.btConnect_Click);
            // 
            // btQueryAll
            // 
            this.btQueryAll.Location = new System.Drawing.Point(232, 260);
            this.btQueryAll.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btQueryAll.Name = "btQueryAll";
            this.btQueryAll.Size = new System.Drawing.Size(150, 46);
            this.btQueryAll.TabIndex = 1;
            this.btQueryAll.Text = "查询";
            this.btQueryAll.UseVisualStyleBackColor = true;
            this.btQueryAll.Click += new System.EventHandler(this.btQueryAll_Click);
            // 
            // btInsertToDatabase
            // 
            this.btInsertToDatabase.Location = new System.Drawing.Point(420, 260);
            this.btInsertToDatabase.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btInsertToDatabase.Name = "btInsertToDatabase";
            this.btInsertToDatabase.Size = new System.Drawing.Size(150, 46);
            this.btInsertToDatabase.TabIndex = 2;
            this.btInsertToDatabase.Text = "插入";
            this.btInsertToDatabase.UseVisualStyleBackColor = true;
            this.btInsertToDatabase.Click += new System.EventHandler(this.btInsertToDatabase_Click);
            // 
            // btModifiFeildValue
            // 
            this.btModifiFeildValue.Location = new System.Drawing.Point(604, 260);
            this.btModifiFeildValue.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btModifiFeildValue.Name = "btModifiFeildValue";
            this.btModifiFeildValue.Size = new System.Drawing.Size(150, 46);
            this.btModifiFeildValue.TabIndex = 3;
            this.btModifiFeildValue.Text = "修改";
            this.btModifiFeildValue.UseVisualStyleBackColor = true;
            this.btModifiFeildValue.Click += new System.EventHandler(this.btModifiFeildValue_Click);
            // 
            // btDeleteFeildValue
            // 
            this.btDeleteFeildValue.Location = new System.Drawing.Point(790, 260);
            this.btDeleteFeildValue.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btDeleteFeildValue.Name = "btDeleteFeildValue";
            this.btDeleteFeildValue.Size = new System.Drawing.Size(150, 46);
            this.btDeleteFeildValue.TabIndex = 4;
            this.btDeleteFeildValue.Text = "删除";
            this.btDeleteFeildValue.UseVisualStyleBackColor = true;
            this.btDeleteFeildValue.Click += new System.EventHandler(this.btDeleteFeildValue_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(54, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 24);
            this.label1.TabIndex = 5;
            this.label1.Text = "操作状态";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(48, 350);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(1088, 524);
            this.dataGridView1.TabIndex = 6;
            // 
            // btDisConnect
            // 
            this.btDisConnect.Location = new System.Drawing.Point(986, 260);
            this.btDisConnect.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btDisConnect.Name = "btDisConnect";
            this.btDisConnect.Size = new System.Drawing.Size(150, 46);
            this.btDisConnect.TabIndex = 7;
            this.btDisConnect.Text = "断开连接";
            this.btDisConnect.UseVisualStyleBackColor = true;
            this.btDisConnect.Click += new System.EventHandler(this.btDisConnect_Click);
            // 
            // tB_Name
            // 
            this.tB_Name.Location = new System.Drawing.Point(114, 90);
            this.tB_Name.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.tB_Name.Name = "tB_Name";
            this.tB_Name.Size = new System.Drawing.Size(174, 35);
            this.tB_Name.TabIndex = 8;
            // 
            // tB_Mail
            // 
            this.tB_Mail.Location = new System.Drawing.Point(368, 90);
            this.tB_Mail.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.tB_Mail.Name = "tB_Mail";
            this.tB_Mail.Size = new System.Drawing.Size(286, 35);
            this.tB_Mail.TabIndex = 8;
            // 
            // tB_Phone
            // 
            this.tB_Phone.Location = new System.Drawing.Point(740, 90);
            this.tB_Phone.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.tB_Phone.Name = "tB_Phone";
            this.tB_Phone.Size = new System.Drawing.Size(174, 35);
            this.tB_Phone.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 98);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 24);
            this.label2.TabIndex = 9;
            this.label2.Text = "姓名";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(298, 98);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 24);
            this.label3.TabIndex = 10;
            this.label3.Text = "邮箱";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(670, 98);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 24);
            this.label4.TabIndex = 10;
            this.label4.Text = "电话";
            // 
            // cB_Sex
            // 
            this.cB_Sex.FormattingEnabled = true;
            this.cB_Sex.Items.AddRange(new object[] {
            "男",
            "女"});
            this.cB_Sex.Location = new System.Drawing.Point(1048, 90);
            this.cB_Sex.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.cB_Sex.Name = "cB_Sex";
            this.cB_Sex.Size = new System.Drawing.Size(78, 32);
            this.cB_Sex.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(978, 98);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 24);
            this.label5.TabIndex = 10;
            this.label5.Text = "性别";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 184);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 24);
            this.label6.TabIndex = 10;
            this.label6.Text = "查询条件";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // cB_tj
            // 
            this.cB_tj.FormattingEnabled = true;
            this.cB_tj.Items.AddRange(new object[] {
            "全部",
            "姓名",
            "邮箱",
            "电话",
            "性别"});
            this.cB_tj.Location = new System.Drawing.Point(196, 176);
            this.cB_tj.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.cB_tj.Name = "cB_tj";
            this.cB_tj.Size = new System.Drawing.Size(182, 32);
            this.cB_tj.TabIndex = 11;
            // 
            // chk_mode
            // 
            this.chk_mode.AutoSize = true;
            this.chk_mode.Location = new System.Drawing.Point(558, 180);
            this.chk_mode.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.chk_mode.Name = "chk_mode";
            this.chk_mode.Size = new System.Drawing.Size(138, 28);
            this.chk_mode.TabIndex = 12;
            this.chk_mode.Text = "模糊查询";
            this.chk_mode.UseVisualStyleBackColor = true;
            this.chk_mode.CheckedChanged += new System.EventHandler(this.chk_mode_CheckedChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1182, 898);
            this.Controls.Add(this.chk_mode);
            this.Controls.Add(this.cB_tj);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cB_Sex);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tB_Phone);
            this.Controls.Add(this.tB_Mail);
            this.Controls.Add(this.tB_Name);
            this.Controls.Add(this.btDisConnect);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btDeleteFeildValue);
            this.Controls.Add(this.btModifiFeildValue);
            this.Controls.Add(this.btInsertToDatabase);
            this.Controls.Add(this.btQueryAll);
            this.Controls.Add(this.btConnect);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "MainForm";
            this.Text = "SQLServerTest";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btConnect;
        private System.Windows.Forms.Button btQueryAll;
        private System.Windows.Forms.Button btInsertToDatabase;
        private System.Windows.Forms.Button btModifiFeildValue;
        private System.Windows.Forms.Button btDeleteFeildValue;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btDisConnect;
        private System.Windows.Forms.TextBox tB_Name;
        private System.Windows.Forms.TextBox tB_Mail;
        private System.Windows.Forms.TextBox tB_Phone;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cB_Sex;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cB_tj;
        private System.Windows.Forms.CheckBox chk_mode;

    }
}

