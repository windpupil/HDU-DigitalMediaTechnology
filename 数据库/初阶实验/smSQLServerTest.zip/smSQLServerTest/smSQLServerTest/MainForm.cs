﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;//添加引用

namespace smSQLServerTest
{
    public partial class MainForm : Form
    {
        SqlConnection myconnection;//定义一个数据库连接对象
        public MainForm()
        {
            InitializeComponent();
            cB_tj.SelectedIndex = 0;
            cB_Sex.SelectedIndex = 0;
        }
        //数据库连接
        private void btConnect_Click(object sender, EventArgs e)
        {
            try
            {
               // myconnection = new SqlConnection("Password=123456;Persist Security Info=True;"+
                //     "User ID=sa;Initial Catalog=WYDB;Data Source=DESKTOP-WANGYON");
                myconnection = new SqlConnection("Password=12345678;Persist Security Info=True;User ID=sa;Initial Catalog=WYDB;Data Source=10.10.16.238");
                myconnection.Open();     //打开数据库 
                label1.Text = "数据库连接成功！";   
            }
            catch (Exception ee)
            {
                MessageBox.Show("数据库连接失败！" + ee.ToString());
            }
        }

        private void btQueryAll_Click(object sender, EventArgs e)
        {
            string strSQL="";
            try
            {
                switch(cB_tj.Text)
                {
                    case "全部":
                        strSQL = "select * From TXL";
                        break;
                    case "姓名":
                        if (chk_mode.Checked)
                            strSQL =string.Format("select * From TXL WHERE name like '%{0}%'",tB_Name.Text);
                        else
                            strSQL =string.Format("select * From TXL WHERE name='{0}'",tB_Name.Text);                        
                        break;
                    case "邮箱":
                        if (chk_mode.Checked)
                            strSQL = string.Format("select * From TXL WHERE mail like '%{0}%'", tB_Mail.Text);
                        else
                            strSQL = string.Format("select * From TXL WHERE mail='{0}'", tB_Mail.Text);
                        break; 
                    case "电话" :
                        if (chk_mode.Checked)
                            strSQL = string.Format("select * From TXL WHERE phone like '%{0}%'", tB_Phone.Text);
                        else
                            strSQL = string.Format("select * From TXL WHERE phone='{0}'", tB_Phone.Text);
                        break;
                    case "性别":
                        if (chk_mode.Checked)
                            strSQL = string.Format("select * From TXL WHERE sex like '%{0}%'", cB_Sex.Text);
                        else
                            strSQL = string.Format("select * From TXL WHERE sex='{0}'", cB_Sex.Text);
                        break; 
                }
                SqlDataAdapter objDataAdpter = new SqlDataAdapter();
                objDataAdpter.SelectCommand = new SqlCommand(strSQL, myconnection);
                DataSet ds = new DataSet();
                objDataAdpter.Fill(ds, "TXL");
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ee)
            {
                MessageBox.Show("查询失败！" + ee.ToString());
            }
        }

        private void btInsertToDatabase_Click(object sender, EventArgs e)
        {
            try
            {
                string strSQL1, strname, strmail, strphone, strsex;
                strname = tB_Name.Text;
                strmail = tB_Mail.Text;
                strphone = tB_Phone.Text;
                strsex = cB_Sex.Text;
                strSQL1=String.Format("insert into TXL values('{0}','{1}','{2}','{3}')",strname,strmail,strphone,strsex);
               // strSQL1 = "insert into TXL values('11','222','33','4')";
                SqlDataAdapter objDataAdpter = new SqlDataAdapter();
                SqlCommand thisCommand = new SqlCommand(strSQL1, myconnection);
                thisCommand.ExecuteNonQuery();
                string strSQL2 = "select * From TXL";
                SqlDataAdapter objDataAdpter1 = new SqlDataAdapter();
                objDataAdpter1.SelectCommand = new SqlCommand(strSQL2, myconnection);
                DataSet ds = new DataSet();
                objDataAdpter1.Fill(ds, "TXL");
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ee)
            {
                MessageBox.Show("插入数据失败！" + ee.ToString());
            }
        }

        private void btModifiFeildValue_Click(object sender, EventArgs e)
        {
            try
            {

                string strSQL1 = string.Format("update TXL set mail='{0}',phone='{1}',sex='{2}' where name='{3}'",
                    tB_Mail.Text, tB_Phone.Text, cB_Sex.Text,tB_Name.Text);
                SqlCommand thisCommand = new SqlCommand(strSQL1, myconnection);
                thisCommand.ExecuteNonQuery();

                string strSQL2 = "select * From TXL";
                SqlDataAdapter objDataAdpter1 = new SqlDataAdapter();
                objDataAdpter1.SelectCommand = new SqlCommand(strSQL2, myconnection);
                DataSet ds = new DataSet();
                objDataAdpter1.Fill(ds, "TXL");
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ee)
            {
                MessageBox.Show("更新数据失败！" + ee.ToString());
            }
        }

        private void btDeleteFeildValue_Click(object sender, EventArgs e)
        {
            try
            {
                string strSQL1 = string.Format("delete from TXL where name='{0}'",tB_Name.Text);
                SqlCommand thisCommand = new SqlCommand(strSQL1, myconnection);
                thisCommand.ExecuteNonQuery();

                string strSQL2 = "select * From TXL";
                SqlDataAdapter objDataAdpter1 = new SqlDataAdapter();
                objDataAdpter1.SelectCommand = new SqlCommand(strSQL2, myconnection);
                DataSet ds = new DataSet();
                objDataAdpter1.Fill(ds, "TXL");
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ee)
            {
                MessageBox.Show("删除数据失败！" + ee.ToString());
            }
        }
        /// <summary>
        //断开与SQL Server数据库的连接
        /// </summary>
        /// 

        public string DisConnect()
        {
            string Result;
            try
            {
                myconnection.Close();
                Result = "数据连接已断开！";
            }
            catch (Exception e)
            {
                MessageBox.Show("数据库断开失败！" + e.ToString());
                Result = "连接成功！";
            }
            return Result;
        }

        private void btDisConnect_Click(object sender, EventArgs e)
        {
            label1.Text = DisConnect();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void chk_mode_CheckedChanged(object sender, EventArgs e)
        {

        }

       
    }
}
